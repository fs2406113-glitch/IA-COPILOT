function gerar() {
  const ideia = document.getElementById("idea").value;
  const resposta = document.getElementById("resposta");

  if (!ideia) {
    resposta.innerText = "Digite uma ideia!";
    return;
  }

  resposta.innerText = "💡 Sugestão: Você pode criar uma feature de " + ideia + " usando IA para automatizar processos e melhorar a experiência do usuário.";
}
